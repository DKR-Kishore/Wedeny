package org.olp.Wedemy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WedemyApplicationTests {

	@Test
	void contextLoads() {
	}

}
